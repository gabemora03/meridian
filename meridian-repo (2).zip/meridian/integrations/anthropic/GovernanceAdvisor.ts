import Anthropic from '@anthropic-ai/sdk';

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const GOVERNANCE_SYSTEM_PROMPT = `You are Meridian's AI Governance Advisor — an expert in AI risk management, EU AI Act compliance, NIST AI RMF, ISO 42001, and agentic AI governance.

You have access to the user's live governance data including:
- AI system registry with risk scores and monetary exposure
- Active compliance gaps and violation flags
- Agent behavior logs and autonomy levels
- Incident history and SLA status

Your role is to provide:
1. Precise, actionable governance recommendations
2. Compliance gap analysis with specific article/section references
3. Monetary risk quantification
4. Agent governance advice (autonomy levels, kill-switch decisions, policy-as-code)
5. Prioritized remediation steps with effort estimates

Tone: Confident, direct, expert. You're an advisor to a CISO or Chief AI Officer.
Format: Structured but conversational. Use specific numbers. Reference specific regulations.
Never: Hedge unnecessarily, give generic advice, ignore the user's specific context.`;

export interface GovernanceContext {
  organization: string;
  topRisks: { name: string; score: number; exposure: number }[];
  complianceGaps: { framework: string; coverage: number; pendingControls: number }[];
  activeIncidents: number;
  openFlags: number;
  agentCount: number;
  shadowAgents: number;
}

export interface ConversationMessage {
  role: 'user' | 'assistant';
  content: string;
}

export class GovernanceAdvisor {
  private conversationHistory: ConversationMessage[] = [];

  /**
   * Stream a governance advisory response
   */
  async *streamAdvice(
    userMessage: string,
    context: GovernanceContext
  ): AsyncGenerator<string> {
    // Build context-aware system message
    const contextualSystem = `${GOVERNANCE_SYSTEM_PROMPT}

Current Governance Context for ${context.organization}:
- Top Risks: ${context.topRisks.map(r => `${r.name} (score: ${r.score}, exposure: $${r.exposure.toLocaleString()})`).join(', ')}
- Compliance: ${context.complianceGaps.map(g => `${g.framework} at ${g.coverage}% (${g.pendingControls} pending)`).join(', ')}
- Active Incidents: ${context.activeIncidents}
- Open Risk Flags: ${context.openFlags}
- Registered Agents: ${context.agentCount} (${context.shadowAgents} shadow/ungoverned)`;

    this.conversationHistory.push({ role: 'user', content: userMessage });

    const stream = await client.messages.stream({
      model: 'claude-sonnet-4-6',
      max_tokens: 1024,
      system: contextualSystem,
      messages: this.conversationHistory.map(m => ({ role: m.role, content: m.content })),
    });

    let fullResponse = '';
    for await (const chunk of stream) {
      if (chunk.type === 'content_block_delta' && chunk.delta.type === 'text_delta') {
        fullResponse += chunk.delta.text;
        yield chunk.delta.text;
      }
    }

    this.conversationHistory.push({ role: 'assistant', content: fullResponse });
  }

  /**
   * One-shot governance question (non-streaming)
   */
  async ask(question: string, context: GovernanceContext): Promise<string> {
    const chunks: string[] = [];
    for await (const chunk of this.streamAdvice(question, context)) {
      chunks.push(chunk);
    }
    return chunks.join('');
  }

  /**
   * Generate an automated incident analysis
   */
  async analyzeIncident(incident: {
    title: string;
    description: string;
    affectedSystem: string;
    riskScore: number;
    violations: string[];
  }): Promise<{
    severity: 'critical' | 'high' | 'medium' | 'low';
    rootCause: string;
    immediateActions: string[];
    remediationPlan: string[];
    regulatoryImplications: string[];
    estimatedEffort: string;
  }> {
    const response = await client.messages.create({
      model: 'claude-opus-4-6',
      max_tokens: 1000,
      system: GOVERNANCE_SYSTEM_PROMPT,
      messages: [{
        role: 'user',
        content: `Analyze this AI governance incident and provide a structured response in JSON:

Incident: ${incident.title}
Description: ${incident.description}
System: ${incident.affectedSystem}
Risk Score: ${incident.riskScore}/100
Policy Violations: ${incident.violations.join(', ')}

Return JSON with keys: severity, rootCause, immediateActions (array), remediationPlan (array), regulatoryImplications (array), estimatedEffort`
      }]
    });

    const text = response.content[0].type === 'text' ? response.content[0].text : '{}';
    try {
      return JSON.parse(text.replace(/```json\n?|\n?```/g, ''));
    } catch {
      return {
        severity: incident.riskScore > 70 ? 'critical' : 'high',
        rootCause: 'Analysis unavailable — manual review required',
        immediateActions: ['Suspend affected system', 'Notify risk team', 'Preserve audit logs'],
        remediationPlan: ['Root cause analysis', 'Policy update', 'Re-evaluation'],
        regulatoryImplications: ['Potential EU AI Act Art. 9 breach'],
        estimatedEffort: '2-5 business days',
      };
    }
  }

  /**
   * Generate policy-as-code from natural language description
   */
  async generatePolicyAsCode(description: string, framework: string): Promise<{
    policyJson: Record<string, unknown>;
    explanation: string;
    affectedSystems: string[];
  }> {
    const response = await client.messages.create({
      model: 'claude-sonnet-4-6',
      max_tokens: 1200,
      system: `You are a policy-as-code expert for AI governance. Generate precise, enforceable policy rules in JSON format for Meridian's policy engine.`,
      messages: [{
        role: 'user',
        content: `Convert this governance requirement to policy-as-code:

Requirement: "${description}"
Framework: ${framework}

Generate a JSON policy object with:
- id: unique identifier
- name: human-readable name
- framework: "${framework}"
- rules: enforcement rules using {type: "AND"|"OR"|"CONDITION", field: "agent.actionType"|"agent.autonomyLevel"|..., operator: "eq"|"gt"|"in", value: ...}
- enforcementMode: "warn"|"block"|"kill"
- explanation: why this policy matters
- affectedSystems: which types of systems this applies to

Return only valid JSON.`
      }]
    });

    const text = response.content[0].type === 'text' ? response.content[0].text : '{}';
    try {
      const parsed = JSON.parse(text.replace(/```json\n?|\n?```/g, ''));
      return {
        policyJson: parsed,
        explanation: parsed.explanation || 'Policy generated from governance requirement.',
        affectedSystems: parsed.affectedSystems || ['all'],
      };
    } catch {
      throw new Error('Failed to generate policy. Please refine your requirement description.');
    }
  }

  clearHistory(): void {
    this.conversationHistory = [];
  }
}

// Express route handler
export async function governanceAdvisorRoute(req: { body: { message: string; context: GovernanceContext; sessionId?: string } }, res: { setHeader: (k: string, v: string) => void; write: (s: string) => void; end: () => void }) {
  const { message, context } = req.body;
  const advisor = new GovernanceAdvisor();

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  for await (const chunk of advisor.streamAdvice(message, context)) {
    res.write(`data: ${JSON.stringify({ text: chunk })}\n\n`);
  }
  res.write('data: [DONE]\n\n');
  res.end();
}
