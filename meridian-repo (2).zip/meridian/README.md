# Meridian — AI Governance Command Center

> **The nervous system for your AI agents.** Real-time governance for autonomous systems — circuit breakers, policy-as-code, and continuous trust scoring across every model, agent, and workflow.

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.110+-green.svg)](https://fastapi.tiangolo.com)
[![Next.js 14](https://img.shields.io/badge/Next.js-14-black.svg)](https://nextjs.org)
[![Docker](https://img.shields.io/badge/Docker-Compose-blue.svg)](https://docs.docker.com/compose/)

---

## What is Meridian?

Meridian is an enterprise AI governance platform purpose-built for the **agentic AI era**. Unlike GRC tools adapted for AI or model monitoring dashboards, Meridian is designed from first principles around:

- **Autonomous systems that act** (not just generate)
- **Real-time enforcement** (not quarterly audits)
- **Developer-native governance** (policy-as-code in your CI/CD)
- **Measurable trust** (live Trust Score API queryable by regulators and customers)

### Six Features With No Equivalent

| Feature | Description | Why It Matters |
|---|---|---|
| **Circuit Breakers** | Autonomous kill switches that trip on risk thresholds | Agentic failures cascade in milliseconds — human reaction is too slow |
| **Policy-as-Code** | Write governance rules in YAML/TypeScript, deploy via CI/CD | Engineers govern what they build, not what compliance writes after |
| **Governance Graph** | Knowledge graph connecting systems → risks → controls → evidence → frameworks | Evidence reuse 4.2× — write once, comply everywhere |
| **Agent Pulse** | Real-time behavioral heartbeat monitoring for every agent | Anomalies in action patterns, not just outputs |
| **Trust Score API** | Live, queryable governance score for any AI system | Your customers call an API, not read a PDF |
| **Bias Audit Engine** | Continuous demographic parity testing with threshold alerts | Fairness is a runtime property, not a one-time assessment |

---

## Repository Structure

```
meridian/
├── packages/
│   ├── frontend/              # Next.js 14 App Router
│   │   ├── src/
│   │   │   ├── app/
│   │   │   │   ├── (marketing)/   # Landing page, pricing
│   │   │   │   ├── (app)/         # Protected app routes
│   │   │   │   │   ├── dashboard/
│   │   │   │   │   ├── registry/
│   │   │   │   │   ├── risk/
│   │   │   │   │   ├── agents/
│   │   │   │   │   ├── graph/
│   │   │   │   │   ├── bias/
│   │   │   │   │   ├── lineage/
│   │   │   │   │   ├── incidents/
│   │   │   │   │   ├── vendors/
│   │   │   │   │   ├── evidence/
│   │   │   │   │   ├── regs/
│   │   │   │   │   ├── roi/
│   │   │   │   │   └── maturity/
│   │   │   │   └── api/           # Next.js API routes (BFF)
│   │   │   ├── components/
│   │   │   │   ├── ui/            # Design system components
│   │   │   │   ├── charts/        # Chart components (Recharts)
│   │   │   │   ├── agents/        # Agent-specific components
│   │   │   │   └── governance/    # Governance-specific components
│   │   │   ├── hooks/
│   │   │   │   ├── useWebSocket.ts     # Real-time agent stream
│   │   │   │   ├── useCircuitBreakers.ts
│   │   │   │   ├── useTrustScore.ts
│   │   │   │   └── useGovernanceGraph.ts
│   │   │   └── lib/
│   │   │       ├── api.ts         # API client (typed)
│   │   │       ├── websocket.ts   # WebSocket manager
│   │   │       └── utils.ts
│   │   ├── public/
│   │   ├── package.json
│   │   └── next.config.mjs
│   │
│   ├── backend/               # FastAPI Python backend
│   │   ├── main.py            # App entry point + all routes
│   │   ├── routes/
│   │   │   ├── systems.py     # AI Registry CRUD
│   │   │   ├── circuit_breakers.py
│   │   │   ├── trust_score.py
│   │   │   ├── bias_audits.py
│   │   │   ├── policy_engine.py
│   │   │   ├── incidents.py
│   │   │   ├── governance_graph.py
│   │   │   ├── vendors.py
│   │   │   ├── evidence.py
│   │   │   └── advisor.py     # Claude AI integration
│   │   ├── models/
│   │   │   ├── ai_system.py
│   │   │   ├── circuit_breaker.py
│   │   │   ├── policy.py
│   │   │   └── trust_score.py
│   │   ├── services/
│   │   │   ├── trust_calculator.py
│   │   │   ├── bias_engine.py
│   │   │   ├── circuit_evaluator.py
│   │   │   ├── governance_graph.py
│   │   │   └── anthropic_advisor.py
│   │   ├── db/
│   │   │   ├── database.py    # SQLAlchemy async
│   │   │   └── migrations/    # Alembic migrations
│   │   ├── requirements.txt
│   │   └── Dockerfile
│   │
│   └── shared/                # Shared TypeScript types
│       └── types/
│           ├── ai-system.ts
│           ├── circuit-breaker.ts
│           ├── trust-score.ts
│           └── governance-graph.ts
│
├── docs/
│   ├── architecture.md
│   ├── api-reference.md
│   ├── policy-as-code.md
│   └── trust-score-spec.md
│
├── scripts/
│   ├── seed.py               # Seed demo data
│   ├── migrate.sh
│   └── deploy.sh
│
├── docker-compose.yml
├── docker-compose.prod.yml
├── .env.example
└── README.md
```

---

## Quick Start

### Prerequisites

- Docker + Docker Compose
- Node.js 20+
- Python 3.11+
- Anthropic API key (for AI Advisor)

### 1. Clone & Configure

```bash
git clone https://github.com/your-org/meridian.git
cd meridian
cp .env.example .env
# Edit .env with your API keys
```

### 2. Start with Docker Compose

```bash
docker-compose up -d
```

This starts:
- **Frontend** → http://localhost:3000
- **Backend API** → http://localhost:8000
- **API Docs** → http://localhost:8000/docs
- **PostgreSQL** → localhost:5432
- **Redis** → localhost:6379

### 3. Or Run Locally

**Backend:**
```bash
cd packages/backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

**Frontend:**
```bash
cd packages/frontend
npm install
npm run dev
```

---

## Environment Variables

```env
# ── Database ──────────────────────────────
DATABASE_URL=postgresql+asyncpg://meridian:secret@localhost/meridian
REDIS_URL=redis://localhost:6379/0

# ── Anthropic (AI Advisor) ────────────────
ANTHROPIC_API_KEY=sk-ant-...

# ── Auth (Clerk) ──────────────────────────
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_...
CLERK_SECRET_KEY=sk_...

# ── App ───────────────────────────────────
NEXT_PUBLIC_API_URL=http://localhost:8000
NEXT_PUBLIC_WS_URL=ws://localhost:8000
```

---

## API Reference

### Core Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/v1/systems` | List all AI systems |
| `POST` | `/api/v1/systems` | Register a new AI system |
| `GET` | `/api/v1/trust-score/{id}` | Get live trust score (public) |
| `GET` | `/api/v1/circuit-breakers` | List all circuit breakers |
| `POST` | `/api/v1/circuit-breakers/{id}/trip` | Emergency halt |
| `POST` | `/api/v1/circuit-breakers/{id}/reset` | Reset after human review |
| `GET` | `/api/v1/bias-audits/{id}` | Get bias audit results |
| `POST` | `/api/v1/bias-audits/{id}/run` | Trigger on-demand audit |
| `POST` | `/api/v1/advisor/chat` | AI governance advisor |
| `GET` | `/api/v1/governance-graph` | Full governance knowledge graph |
| `GET` | `/api/v1/analytics/roi` | Calculate governance ROI |
| `GET` | `/api/v1/analytics/dashboard` | Dashboard KPIs |
| `WS` | `/ws/agents` | Real-time agent stream |

### WebSocket Events

Connect to `ws://localhost:8000/ws/agents` to receive real-time events:

```typescript
type MeridianEvent =
  | { type: 'heartbeat'; agent_id: string; status: AgentStatus; anomaly_score: number }
  | { type: 'circuit_breaker_tripped'; circuit_breaker_id: string; action: string }
  | { type: 'circuit_breaker_reset'; circuit_breaker_id: string }
  | { type: 'incident_created'; incident: IncidentReport }
  | { type: 'system_registered'; system: AISystem }
  | { type: 'policy_deployed'; policy_id: string; name: string };
```

---

## Policy-as-Code

Meridian policies live in your repo as YAML or TypeScript. They enforce governance rules at inference time.

### YAML Policy

```yaml
# .meridian/policies/credit-model.yaml
policy:
  name: "credit-decisioning-v3"
  version: "2.1.0"
  frameworks: ["eu-ai-act", "nist-rmf", "nyc-ll-144"]

risk_thresholds:
  bias:
    demographic_parity: 0.05      # max 5 percentage point gap
    action: circuit_break
    notify: ["risk@company.com"]
  drift:
    f1_degradation: 0.03          # 3% F1 score drop triggers alert
    action: alert_and_retrain

circuit_breakers:
  - name: "Bias Guard"
    trigger: "bias_score > 0.05"
    action: halt_production
    
  - name: "Volume Gate"
    trigger: "daily_decisions > 100000"
    action: require_human_review

autonomy_level: recommend          # observe | recommend | execute_with_limits | full
human_checkpoints:
  - trigger: "confidence < 0.70"
    requirement: senior_analyst_sign_off

evidence_requirements:
  - type: bias_audit
    frequency: continuous
    maps_to: ["EU AI Act Art. 9.5", "NIST MANAGE 2.2", "NYC LL 144"]
  - type: technical_documentation
    frequency: on_change
    maps_to: ["EU AI Act Art. 11"]
```

### TypeScript Policy (advanced)

```typescript
// .meridian/policies/credit-model.ts
import { definePolicy, circuitBreaker, biasGuard } from '@meridian/sdk';

export default definePolicy({
  name: 'credit-decisioning-v3',
  frameworks: ['eu-ai-act', 'nist-rmf'],
  
  circuitBreakers: [
    circuitBreaker({
      name: 'Bias Guard',
      evaluate: async (metrics) => metrics.demographicParity > 0.05,
      action: 'halt_production',
      notify: ['risk@company.com'],
    }),
    circuitBreaker({
      name: 'Spend Limit',
      evaluate: async (metrics) => metrics.dailySpend > 10_000,
      action: 'require_human_review',
    }),
  ],

  biasGuards: [
    biasGuard({
      attributes: ['gender', 'race', 'age'],
      metric: 'demographic_parity',
      threshold: 0.05,
    }),
  ],

  onTrip: async (event) => {
    await notifySlack('#governance-alerts', event);
    await createIncident(event);
  },
});
```

---

## Trust Score API

The Trust Score API is a public endpoint that lets customers, partners, and regulators verify your AI governance in real time — no PDFs, no questionnaires.

```bash
curl https://api.meridian.ai/v1/trust-score/credit-decisioning-v3 \
  -H "Authorization: Bearer your-public-api-key"
```

Response:
```json
{
  "system": "credit-decisioning-v3",
  "score": 82,
  "grade": "B+",
  "dimensions": {
    "bias_fairness": 42,
    "security_posture": 91,
    "compliance_coverage": 88,
    "explainability": 72,
    "drift_stability": 87,
    "evidence_quality": 94
  },
  "frameworks": ["eu-ai-act", "nist-rmf"],
  "certified": true,
  "assessed_at": "2026-04-29T09:14:02Z",
  "next_assessment": "2026-04-29T10:14:02Z"
}
```

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        MERIDIAN PLATFORM                         │
│                                                                   │
│  ┌──────────────┐    ┌──────────────────────────────────────┐   │
│  │   Next.js    │    │           FastAPI Backend            │   │
│  │   Frontend   │◄──►│                                      │   │
│  │              │    │  ┌──────────┐  ┌──────────────────┐  │   │
│  │  - Dashboard │    │  │ Registry │  │ Circuit Breaker  │  │   │
│  │  - Agent Mon │    │  │  API     │  │    Evaluator     │  │   │
│  │  - Policy Ed │    │  └──────────┘  └──────────────────┘  │   │
│  │  - Bias Aud. │    │  ┌──────────┐  ┌──────────────────┐  │   │
│  └──────────────┘    │  │ Trust    │  │  Bias Audit      │  │   │
│                      │  │ Score    │  │  Engine          │  │   │
│  ┌──────────────┐    │  └──────────┘  └──────────────────┘  │   │
│  │  WebSocket   │◄──►│  ┌──────────┐  ┌──────────────────┐  │   │
│  │  Real-time   │    │  │ Policy   │  │  Governance      │  │   │
│  │  Agent Stream│    │  │  Engine  │  │  Graph           │  │   │
│  └──────────────┘    │  └──────────┘  └──────────────────┘  │   │
│                      │  ┌──────────────────────────────────┐  │   │
│                      │  │     Anthropic Claude Advisor     │  │   │
│                      │  └──────────────────────────────────┘  │   │
│                      └──────────────────────────────────────┘   │
│                                                                   │
│  ┌─────────────┐  ┌─────────────┐  ┌──────────────────────────┐ │
│  │  PostgreSQL  │  │    Redis    │  │   Your AI Systems        │ │
│  │  (storage)  │  │  (pub/sub)  │  │   (agents, models, apps) │ │
│  └─────────────┘  └─────────────┘  └──────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

### Key Design Decisions

- **WebSockets for agent heartbeats** — HTTP polling is too slow for agentic failures that cascade in milliseconds
- **Circuit breakers run in-process** — network latency in the enforcement path creates a gap attackers (and bugs) exploit
- **Policy-as-code in YAML/TS** — YAML for compliance teams, TypeScript for engineers; same enforcement engine
- **Knowledge graph for evidence** — relational databases create evidence silos; a graph makes reuse natural
- **Trust Score as public API** — compliance as a legibility problem, not a documentation problem

---

## Deployment

### Docker Compose (Development)

```bash
docker-compose up -d
```

### Kubernetes (Production)

```bash
kubectl apply -f k8s/
```

### Environment-specific configs

| Environment | Config | Database | Cache |
|---|---|---|---|
| Development | `docker-compose.yml` | PostgreSQL (local) | Redis (local) |
| Staging | `docker-compose.staging.yml` | RDS PostgreSQL | ElastiCache |
| Production | `k8s/` | RDS PostgreSQL Multi-AZ | ElastiCache Cluster |

---

## Integrations

Meridian connects to your existing stack:

| Integration | Type | Description |
|---|---|---|
| **Anthropic Claude** | AI Advisor | Governance advice and risk assessment |
| **GitHub Actions** | CI/CD | Policy-as-code deployment in pipeline |
| **Slack** | Alerts | Circuit breaker trips, incident notifications |
| **Jira** | Incident | Auto-create tickets from governance incidents |
| **Snowflake** | Data | Model training data lineage |
| **Databricks** | MLOps | Model monitoring integration |
| **AWS SageMaker** | Inference | Middleware policy enforcement |
| **Azure ML** | Inference | Middleware policy enforcement |
| **ServiceNow** | GRC | Evidence sync to existing GRC workflows |
| **PagerDuty** | On-call | Critical incident escalation |

---

## Regulatory Frameworks Supported

| Framework | Coverage | Auto-mapped |
|---|---|---|
| EU AI Act | 88% (14 gaps) | ✓ |
| NIST AI RMF v1.0 | 94% | ✓ |
| ISO/IEC 42001:2023 | 79% | ✓ |
| SOC 2 Type II | 97% | ✓ |
| GDPR (AI provisions) | 85% | ✓ |
| NYC Local Law 144 | 100% | ✓ |
| HITRUST AI | 52% | ✓ |
| UK AI Safety Framework | 71% | In progress |
| Canada AIDA | 63% | In progress |
| Singapore FEAT Principles | 89% | ✓ |

---

## Contributing

1. Fork the repo
2. Create a feature branch: `git checkout -b feature/circuit-breaker-webhook`
3. Make your changes with tests
4. Submit a pull request

### Development Standards

- **Backend**: Type annotations everywhere, pytest for all routes, async-first
- **Frontend**: TypeScript strict mode, Playwright E2E tests
- **Policies**: All policy changes require peer review + automated validation
- **APIs**: OpenAPI spec must stay in sync with implementation

---

## License

MIT License — see [LICENSE](LICENSE) for details.

---

## References

1. Singh, Navrina. "The ROI of AI Governance: A 2026 Executive Playbook." Credo AI, 2026.
2. "Validity is what you need." arXiv:2510.27628, October 2025.
3. LangChain. "State of AI Agents Report." 2025.
4. Monitaur. "The current state of agentic AI and governance." Webinar, September 2025.
5. McKinsey & Company. "Global AI Survey." 2025.
6. Forrester Research. "The Forrester Wave™: AI Governance Solutions, Q3 2025."
7. Woodbury, Rex. "The Interior Design of Software." Digital Native, April 2026.

---

*Built with conviction that governance is the highest-ROI infrastructure in the AI era.*
