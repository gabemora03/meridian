/**
 * @meridian/sdk
 * Official JavaScript/TypeScript SDK for the Meridian AI Governance Platform
 *
 * Install: npm install @meridian/sdk
 * Docs: https://docs.meridian.ai/sdk
 */

export interface MeridianConfig {
  apiKey: string;
  baseUrl?: string;
  organizationId?: string;
  timeout?: number;
}

export interface AgentRegistration {
  name: string;
  type: 'internal' | 'vendor' | 'workflow';
  autonomyLevel: 'observe' | 'recommend' | 'propose' | 'execute-limited';
  permissions: string[];
  owner: string;
  description: string;
  parentAgentId?: string;
  metadata?: Record<string, unknown>;
}

export interface ActionReport {
  agentId: string;
  actionType: 'read' | 'write' | 'execute' | 'commit' | 'send' | 'delete';
  resource: string;
  payload?: unknown;
  metadata?: Record<string, unknown>;
}

export interface GovernanceDecision {
  allowed: boolean;
  riskScore: number;
  violations: string[];
  recommendation?: string;
  traceId: string;
}

/**
 * Main Meridian SDK client
 *
 * @example
 * ```typescript
 * import { Meridian } from '@meridian/sdk';
 *
 * const meridian = new Meridian({ apiKey: process.env.MERIDIAN_API_KEY });
 *
 * // Register an agent
 * const agent = await meridian.agents.register({
 *   name: 'My Email Agent',
 *   autonomyLevel: 'recommend',
 *   permissions: ['read', 'draft'],
 *   owner: 'marketing-team',
 * });
 *
 * // Report an action BEFORE executing it (enforcement mode)
 * const decision = await meridian.agents.reportAction({
 *   agentId: agent.id,
 *   actionType: 'send',
 *   resource: 'email-api',
 * });
 *
 * if (decision.allowed) {
 *   await sendEmail(...);
 * } else {
 *   console.log('Blocked:', decision.violations);
 * }
 * ```
 */
export class Meridian {
  private config: Required<MeridianConfig>;

  public readonly agents: AgentAPI;
  public readonly risk: RiskAPI;
  public readonly policy: PolicyAPI;
  public readonly registry: RegistryAPI;
  public readonly incidents: IncidentAPI;
  public readonly advisor: AdvisorAPI;

  constructor(config: MeridianConfig) {
    this.config = {
      apiKey: config.apiKey,
      baseUrl: config.baseUrl || 'https://api.meridian.ai',
      organizationId: config.organizationId || '',
      timeout: config.timeout || 5000,
    };

    const http = this.createHttpClient();
    this.agents = new AgentAPI(http);
    this.risk = new RiskAPI(http);
    this.policy = new PolicyAPI(http);
    this.registry = new RegistryAPI(http);
    this.incidents = new IncidentAPI(http);
    this.advisor = new AdvisorAPI(http);
  }

  private createHttpClient() {
    const { apiKey, baseUrl, timeout } = this.config;

    return {
      get: <T>(path: string, params?: Record<string, string>) =>
        this.request<T>('GET', `${baseUrl}${path}`, params),
      post: <T>(path: string, body?: unknown) =>
        this.request<T>('POST', `${baseUrl}${path}`, undefined, body),
      patch: <T>(path: string, body?: unknown) =>
        this.request<T>('PATCH', `${baseUrl}${path}`, undefined, body),
      delete: <T>(path: string) =>
        this.request<T>('DELETE', `${baseUrl}${path}`),
    };

    async function request<T>(method: string, url: string, params?: Record<string, string>, body?: unknown): Promise<T> {
      const urlObj = new URL(url);
      if (params) Object.entries(params).forEach(([k, v]) => urlObj.searchParams.set(k, v));

      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), timeout);

      try {
        const res = await fetch(urlObj.toString(), {
          method,
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
            'X-Meridian-SDK': '2.0.0',
          },
          body: body ? JSON.stringify(body) : undefined,
          signal: ctrl.signal,
        });

        if (!res.ok) {
          const error = await res.json().catch(() => ({})) as { error?: string };
          throw new MeridianError(error.error || 'Request failed', res.status);
        }

        return res.json() as Promise<T>;
      } finally {
        clearTimeout(timer);
      }
    }
  }

  private request<T>(method: string, url: string, params?: Record<string, string>, body?: unknown): Promise<T> {
    // This is a helper that the http client above closes over
    return this.createHttpClient().post<T>(url, body);
  }

  /**
   * Real-time WebSocket connection for live agent monitoring
   */
  connectRealtime(onMessage: (msg: unknown) => void): WebSocket {
    const wsUrl = this.config.baseUrl.replace('https://', 'wss://').replace('http://', 'ws://');
    const ws = new WebSocket(`${wsUrl}/ws`);
    ws.onmessage = (e) => onMessage(JSON.parse(e.data));
    return ws;
  }
}

class AgentAPI {
  constructor(private http: ReturnType<Meridian['createHttpClient']>) {}

  register(data: AgentRegistration) {
    return this.http.post<{ id: string; name: string; createdAt: string }>('/api/v1/agents', data);
  }

  list() {
    return this.http.get<{ agents: AgentRegistration[] }>('/api/v1/agents');
  }

  /**
   * Report an agent action for governance evaluation.
   * In enforcement mode, you MUST check the returned `allowed` before executing.
   */
  async reportAction(action: ActionReport): Promise<GovernanceDecision> {
    return this.http.post<GovernanceDecision>('/api/v1/agents/actions', action);
  }

  /**
   * Wrap any async function with automatic governance enforcement.
   * The action is blocked if policy violations are detected.
   *
   * @example
   * await meridian.agents.govern(agentId, 'send', 'email-api', async () => {
   *   await sendEmail(payload);
   * });
   */
  async govern<T>(
    agentId: string,
    actionType: ActionReport['actionType'],
    resource: string,
    fn: () => Promise<T>,
    payload?: unknown
  ): Promise<T> {
    const decision = await this.reportAction({ agentId, actionType, resource, payload });

    if (!decision.allowed) {
      throw new GovernanceBlockedError(
        `Action blocked by Meridian policy: ${decision.violations.join(', ')}`,
        decision
      );
    }

    return fn();
  }

  kill(agentId: string, reason: string) {
    return this.http.post(`/api/v1/agents/${agentId}/kill`, { reason });
  }

  suspend(agentId: string) {
    return this.http.post(`/api/v1/agents/${agentId}/suspend`);
  }

  getTrace(agentId: string, traceId: string) {
    return this.http.get(`/api/v1/agents/${agentId}/traces/${traceId}`);
  }
}

class RiskAPI {
  constructor(private http: ReturnType<Meridian['createHttpClient']>) {}

  assess(systemId: string) {
    return this.http.post(`/api/v1/risk/assess`, { systemId });
  }

  getAssessment(systemId: string) {
    return this.http.get(`/api/v1/risk/${systemId}`);
  }

  listFlags(filters?: { severity?: string; status?: string }) {
    return this.http.get('/api/v1/risk/flags', filters);
  }
}

class PolicyAPI {
  constructor(private http: ReturnType<Meridian['createHttpClient']>) {}

  list() { return this.http.get('/api/v1/policy'); }
  create(policy: unknown) { return this.http.post('/api/v1/policy', policy); }
  evaluate(systemId: string, frameworkId: string) {
    return this.http.post('/api/v1/policy/evaluate', { systemId, frameworkId });
  }
  generateFromNaturalLanguage(description: string, framework: string) {
    return this.http.post('/api/v1/policy/generate', { description, framework });
  }
}

class RegistryAPI {
  constructor(private http: ReturnType<Meridian['createHttpClient']>) {}
  list(filters?: Record<string, string>) { return this.http.get('/api/v1/registry', filters); }
  register(system: unknown) { return this.http.post('/api/v1/registry', system); }
  get(id: string) { return this.http.get(`/api/v1/registry/${id}`); }
}

class IncidentAPI {
  constructor(private http: ReturnType<Meridian['createHttpClient']>) {}
  list() { return this.http.get('/api/v1/incidents'); }
  create(incident: unknown) { return this.http.post('/api/v1/incidents', incident); }
  resolve(id: string, resolution: unknown) { return this.http.patch(`/api/v1/incidents/${id}`, { status: 'resolved', resolution }); }
  analyze(id: string) { return this.http.post(`/api/v1/incidents/${id}/analyze`); }
}

class AdvisorAPI {
  constructor(private http: ReturnType<Meridian['createHttpClient']>) {}
  ask(message: string, context?: unknown) {
    return this.http.post('/api/v1/advisor', { message, context });
  }
}

export class MeridianError extends Error {
  constructor(message: string, public statusCode: number) {
    super(message);
    this.name = 'MeridianError';
  }
}

export class GovernanceBlockedError extends Error {
  constructor(message: string, public decision: GovernanceDecision) {
    super(message);
    this.name = 'GovernanceBlockedError';
  }
}

// LangChain integration helper
export function createMeridianLangChainMiddleware(meridian: Meridian, agentId: string) {
  return {
    async beforeToolCall(toolName: string, input: unknown) {
      const decision = await meridian.agents.reportAction({
        agentId,
        actionType: 'execute',
        resource: toolName,
        payload: input,
      });
      if (!decision.allowed) {
        throw new GovernanceBlockedError(`LangChain tool "${toolName}" blocked`, decision);
      }
      return input;
    }
  };
}

// Default export
export default Meridian;
