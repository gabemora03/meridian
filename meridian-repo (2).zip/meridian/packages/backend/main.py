"""
Meridian AI Governance Platform — Backend API
FastAPI + WebSocket + PostgreSQL + Redis + Anthropic
"""

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Depends, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from contextlib import asynccontextmanager
from typing import Optional
import asyncio
import json
import time
import math
import random
from datetime import datetime, timedelta

# ── MODELS ──────────────────────────────────────────────────────────────────
from pydantic import BaseModel, Field
from enum import Enum
from uuid import uuid4

class RiskLevel(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"

class AgentStatus(str, Enum):
    ACTIVE = "active"
    WARNING = "warning"
    CRITICAL = "critical"
    BLOCKED = "blocked"
    SHADOW = "shadow"

class CircuitBreakerState(str, Enum):
    ARMED = "armed"
    TRIPPED = "tripped"
    DISABLED = "disabled"

class AISystem(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid4()))
    name: str
    type: str  # model | agent | application | vendor
    owner: str
    risk_level: RiskLevel
    frameworks: list[str]
    monetary_exposure: float  # USD
    status: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
    last_assessed: datetime = Field(default_factory=datetime.utcnow)

class CircuitBreaker(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid4()))
    system_id: str
    name: str
    trigger_expression: str
    current_value: float
    threshold: float
    state: CircuitBreakerState
    action: str  # halt_production | alert_and_retrain | require_human_review | notify
    notify_emails: list[str] = []
    tripped_at: Optional[datetime] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)

class AgentHeartbeat(BaseModel):
    agent_id: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    action_count: int
    error_rate: float
    spend_amount: float
    tool_calls: list[str]
    anomaly_score: float  # 0.0 - 1.0
    status: AgentStatus

class PolicyRule(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid4()))
    name: str
    system_id: str
    yaml_content: str
    version: str
    frameworks: list[str]
    is_active: bool = True
    created_by: str
    created_at: datetime = Field(default_factory=datetime.utcnow)

class TrustScore(BaseModel):
    system_id: str
    score: int  # 0-100
    grade: str  # A+ through F
    dimensions: dict[str, int]
    certified: bool
    assessed_at: datetime = Field(default_factory=datetime.utcnow)
    frameworks: list[str]

class BiasAuditResult(BaseModel):
    system_id: str
    attribute: str
    group: str
    approval_rate: float
    baseline_rate: float
    disparity: float  # difference from baseline
    severity: RiskLevel
    audit_date: datetime = Field(default_factory=datetime.utcnow)

class GovernanceAdvisorMessage(BaseModel):
    message: str
    system_context: Optional[str] = None

class IncidentReport(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid4()))
    system_id: str
    title: str
    description: str
    severity: RiskLevel
    status: str  # open | investigating | resolved
    sla_hours: int
    opened_at: datetime = Field(default_factory=datetime.utcnow)
    resolved_at: Optional[datetime] = None
    owner: str

# ── IN-MEMORY STORE (Replace with PostgreSQL in prod) ───────────────────────
db = {
    "systems": {},
    "circuit_breakers": {},
    "policies": {},
    "incidents": {},
    "heartbeats": {},
}

# ── WEBSOCKET CONNECTION MANAGER ─────────────────────────────────────────────
class ConnectionManager:
    def __init__(self):
        self.active: list[WebSocket] = []

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self.active.append(ws)

    def disconnect(self, ws: WebSocket):
        self.active.remove(ws) if ws in self.active else None

    async def broadcast(self, data: dict):
        for ws in self.active.copy():
            try:
                await ws.send_json(data)
            except Exception:
                self.disconnect(ws)

manager = ConnectionManager()

# ── STARTUP / SHUTDOWN ───────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Seed demo data
    seed_demo_data()
    # Start background tasks
    asyncio.create_task(agent_heartbeat_broadcaster())
    asyncio.create_task(circuit_breaker_evaluator())
    yield

def seed_demo_data():
    systems_data = [
        {"id": "credit-v3", "name": "Credit Decisioning v3", "type": "model", "owner": "Risk Analytics", "risk_level": "critical", "frameworks": ["eu-ai-act", "nist-rmf"], "monetary_exposure": 1900000, "status": "review"},
        {"id": "doc-agent", "name": "Document Processor Agent", "type": "agent", "owner": "Operations", "risk_level": "high", "frameworks": ["iso-42001", "soc2"], "monetary_exposure": 540000, "status": "active"},
        {"id": "hr-screener", "name": "HR Resume Screener", "type": "application", "owner": "Human Resources", "risk_level": "high", "frameworks": ["nist-rmf", "gdpr"], "monetary_exposure": 620000, "status": "review"},
        {"id": "fraud-v7", "name": "Fraud Detection v7", "type": "model", "owner": "Payments Security", "risk_level": "medium", "frameworks": ["soc2", "pci"], "monetary_exposure": 410000, "status": "compliant"},
        {"id": "cx-bot", "name": "Customer Support Bot", "type": "agent", "owner": "CX Operations", "risk_level": "low", "frameworks": ["gdpr", "iso-42001"], "monetary_exposure": 85000, "status": "active"},
    ]
    for s in systems_data:
        db["systems"][s["id"]] = s

    cbs = [
        {"id": "cb-bias-credit", "system_id": "credit-v3", "name": "Bias Guard", "trigger_expression": "bias_score > 0.05", "current_value": 0.021, "threshold": 0.05, "state": "armed", "action": "halt_production", "notify_emails": ["risk@company.com"]},
        {"id": "cb-spend-proc", "system_id": "doc-agent", "name": "Spend Limit", "trigger_expression": "daily_spend > 10000", "current_value": 14200, "threshold": 10000, "state": "tripped", "action": "halt_production", "notify_emails": ["finance@company.com"]},
        {"id": "cb-drift-fraud", "system_id": "fraud-v7", "name": "Drift Detector", "trigger_expression": "f1_drop > 0.03", "current_value": 0.012, "threshold": 0.03, "state": "armed", "action": "alert_and_retrain"},
    ]
    for cb in cbs:
        db["circuit_breakers"][cb["id"]] = cb

    incidents_data = [
        {"id": "inc-001", "system_id": "credit-v3", "title": "Critical Bias Drift — Credit Decisioning v3", "description": "Demographic parity violation detected. Race attribute. EU AI Act Art. 9 breach.", "severity": "critical", "status": "open", "sla_hours": 24, "owner": "Risk Team"},
        {"id": "inc-002", "system_id": "doc-agent", "title": "Spend Runaway — Procurement Agent", "description": "Daily spend limit exceeded. Circuit breaker tripped at $14,200.", "severity": "high", "status": "investigating", "sla_hours": 8, "owner": "Finance Team"},
    ]
    for inc in incidents_data:
        db["incidents"][inc["id"]] = inc

# ── BACKGROUND TASKS ─────────────────────────────────────────────────────────
async def agent_heartbeat_broadcaster():
    """Simulate real-time agent heartbeats and broadcast via WebSocket."""
    agents = ["credit-v3", "doc-agent", "hr-screener", "fraud-v7", "cx-bot"]
    while True:
        for agent_id in agents:
            anomaly = 0.8 if agent_id == "credit-v3" else random.uniform(0.0, 0.15)
            status = AgentStatus.CRITICAL if anomaly > 0.7 else AgentStatus.WARNING if anomaly > 0.4 else AgentStatus.ACTIVE
            hb = {
                "type": "heartbeat",
                "agent_id": agent_id,
                "timestamp": datetime.utcnow().isoformat(),
                "action_count": random.randint(100, 1000),
                "error_rate": round(random.uniform(0, 0.05 if agent_id != "credit-v3" else 0.15), 4),
                "anomaly_score": round(anomaly, 3),
                "status": status.value,
                "tool_calls": random.sample(["read_db", "write_db", "call_api", "send_email", "update_record"], k=random.randint(1, 3)),
            }
            await manager.broadcast(hb)
        await asyncio.sleep(2)

async def circuit_breaker_evaluator():
    """Continuously evaluate circuit breakers and trip if thresholds exceeded."""
    while True:
        for cb_id, cb in db["circuit_breakers"].items():
            if cb["state"] == "armed":
                # Simulate drift in values
                noise = random.uniform(-0.002, 0.002)
                cb["current_value"] += noise
                # Check if threshold exceeded
                if cb["current_value"] > cb["threshold"] and cb["state"] == "armed":
                    cb["state"] = "tripped"
                    cb["tripped_at"] = datetime.utcnow().isoformat()
                    await manager.broadcast({
                        "type": "circuit_breaker_tripped",
                        "circuit_breaker_id": cb_id,
                        "name": cb["name"],
                        "system_id": cb["system_id"],
                        "current_value": cb["current_value"],
                        "threshold": cb["threshold"],
                        "action": cb["action"],
                        "timestamp": datetime.utcnow().isoformat(),
                    })
        await asyncio.sleep(5)

# ── TRUST SCORE CALCULATOR ────────────────────────────────────────────────────
def calculate_trust_score(system_id: str) -> TrustScore:
    """Calculate a live trust score for an AI system across multiple dimensions."""
    dimensions = {
        "bias_fairness": random.randint(55, 95),
        "security_posture": random.randint(70, 98),
        "compliance_coverage": random.randint(60, 97),
        "explainability": random.randint(55, 90),
        "drift_stability": random.randint(65, 95),
        "evidence_quality": random.randint(70, 98),
    }
    if system_id == "credit-v3":
        dimensions["bias_fairness"] = 42  # Critical bias issue

    score = int(sum(dimensions.values()) / len(dimensions))
    grade = "A+" if score >= 95 else "A" if score >= 90 else "B+" if score >= 85 else "B" if score >= 80 else "C+" if score >= 75 else "C" if score >= 70 else "D" if score >= 60 else "F"

    system = db["systems"].get(system_id, {})
    return TrustScore(
        system_id=system_id,
        score=score,
        grade=grade,
        dimensions=dimensions,
        certified=score >= 75,
        frameworks=system.get("frameworks", []),
    )

# ── AI GOVERNANCE ADVISOR ─────────────────────────────────────────────────────
async def get_governance_advice(message: str, system_context: Optional[str]) -> str:
    """
    Call Anthropic Claude API for governance advice.
    Replace with actual API call in production.
    """
    # In production, this calls Anthropic's API:
    # from anthropic import Anthropic
    # client = Anthropic()
    # response = client.messages.create(
    #     model="claude-opus-4-6",
    #     max_tokens=1024,
    #     system=GOVERNANCE_ADVISOR_SYSTEM_PROMPT,
    #     messages=[{"role": "user", "content": message}]
    # )
    # return response.content[0].text

    responses = {
        "bias": "Your Credit Decisioning v3 system has a critical demographic parity violation. Black applicants see a 16pp lower approval rate vs. the baseline. This triggers EU AI Act Article 9.5 and NYC Local Law 144. Recommended: (1) Immediate circuit breaker engagement, (2) Retraining with fairness constraints (e.g., Reweighing or Adversarial Debiasing), (3) Human review for all pending decisions. Estimated remediation time: 2-3 weeks.",
        "eu ai act": "Your EU AI Act coverage is 88%. The 14 remaining controls are in Article 9 (risk management system) and Article 10 (data governance). Priority gaps: (1) Technical documentation update for Credit v3 post-bias incident, (2) Post-market monitoring log for the past 90 days, (3) Human oversight attestation for high-risk decision systems.",
        "circuit breaker": "Your Spend Limit circuit breaker tripped at $14,200 against a $10,000 threshold on the Procurement Agent. Actions recommended: (1) Review all committed transactions above $10K in the last 24h, (2) Reset circuit breaker only after root cause analysis is complete, (3) Consider lowering threshold to $7,500 with a warning at $8,000.",
        "default": "Based on your current governance posture (score: 82/B+), your highest-priority actions are: (1) Remediate Credit v3 bias drift — SLA breach imminent, (2) Complete 14 pending EU AI Act controls before August 2026 enforcement, (3) Reset the tripped Spend Limit circuit breaker on Procurement Agent, (4) Submit missing OpenAI documentation to Vendor Portal. Estimated total remediation effort: ~40 hours across 3 teams.",
    }

    lower = message.lower()
    for key, response in responses.items():
        if key in lower:
            return response
    return responses["default"]

# ── APP INIT ─────────────────────────────────────────────────────────────────
app = FastAPI(
    title="Meridian AI Governance API",
    description="Real-time governance for autonomous AI systems",
    version="2.0.0",
    lifespan=lifespan,
)

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
app.add_middleware(GZipMiddleware)

# ── ROUTES: AI REGISTRY ──────────────────────────────────────────────────────
@app.get("/api/v1/systems", response_model=list[dict], tags=["Registry"])
async def list_systems(risk_level: Optional[str] = None, system_type: Optional[str] = None):
    """List all governed AI systems with optional filtering."""
    systems = list(db["systems"].values())
    if risk_level:
        systems = [s for s in systems if s["risk_level"] == risk_level]
    if system_type:
        systems = [s for s in systems if s["type"] == system_type]
    return systems

@app.get("/api/v1/systems/{system_id}", tags=["Registry"])
async def get_system(system_id: str):
    """Get details for a specific AI system."""
    if system_id not in db["systems"]:
        raise HTTPException(status_code=404, detail="System not found")
    return db["systems"][system_id]

@app.post("/api/v1/systems", status_code=201, tags=["Registry"])
async def register_system(system: AISystem):
    """Register a new AI system for governance."""
    db["systems"][system.id] = system.model_dump()
    await manager.broadcast({"type": "system_registered", "system": system.model_dump(mode="json")})
    return system

@app.delete("/api/v1/systems/{system_id}", tags=["Registry"])
async def deregister_system(system_id: str):
    """Remove a system from the registry."""
    if system_id not in db["systems"]:
        raise HTTPException(status_code=404, detail="System not found")
    del db["systems"][system_id]
    return {"status": "deleted"}

# ── ROUTES: CIRCUIT BREAKERS ─────────────────────────────────────────────────
@app.get("/api/v1/circuit-breakers", tags=["Circuit Breakers"])
async def list_circuit_breakers(system_id: Optional[str] = None):
    """List all circuit breakers, optionally filtered by system."""
    cbs = list(db["circuit_breakers"].values())
    if system_id:
        cbs = [cb for cb in cbs if cb["system_id"] == system_id]
    return cbs

@app.post("/api/v1/circuit-breakers", status_code=201, tags=["Circuit Breakers"])
async def create_circuit_breaker(cb: CircuitBreaker):
    """Create a new circuit breaker for an AI system."""
    db["circuit_breakers"][cb.id] = cb.model_dump()
    return cb

@app.post("/api/v1/circuit-breakers/{cb_id}/reset", tags=["Circuit Breakers"])
async def reset_circuit_breaker(cb_id: str, background_tasks: BackgroundTasks):
    """Reset a tripped circuit breaker (requires human authorization)."""
    if cb_id not in db["circuit_breakers"]:
        raise HTTPException(status_code=404, detail="Circuit breaker not found")
    cb = db["circuit_breakers"][cb_id]
    if cb["state"] != "tripped":
        raise HTTPException(status_code=400, detail="Circuit breaker is not in tripped state")
    cb["state"] = "armed"
    cb["tripped_at"] = None
    await manager.broadcast({"type": "circuit_breaker_reset", "circuit_breaker_id": cb_id})
    return {"status": "reset", "circuit_breaker": cb}

@app.post("/api/v1/circuit-breakers/{cb_id}/trip", tags=["Circuit Breakers"])
async def manually_trip(cb_id: str):
    """Manually trip a circuit breaker (emergency shutdown)."""
    if cb_id not in db["circuit_breakers"]:
        raise HTTPException(status_code=404, detail="Circuit breaker not found")
    cb = db["circuit_breakers"][cb_id]
    cb["state"] = "tripped"
    cb["tripped_at"] = datetime.utcnow().isoformat()
    await manager.broadcast({"type": "circuit_breaker_tripped", "circuit_breaker_id": cb_id, "manual": True})
    return {"status": "tripped", "circuit_breaker": cb}

# ── ROUTES: TRUST SCORE ──────────────────────────────────────────────────────
@app.get("/api/v1/trust-score/{system_id}", tags=["Trust Score"])
async def get_trust_score(system_id: str):
    """
    Get the live Trust Score for an AI system.
    This endpoint is publicly queryable by partners, customers, and regulators.
    """
    if system_id not in db["systems"]:
        raise HTTPException(status_code=404, detail="System not found")
    score = calculate_trust_score(system_id)
    return score

@app.get("/api/v1/trust-score/{system_id}/history", tags=["Trust Score"])
async def get_trust_score_history(system_id: str, days: int = 30):
    """Get trust score history for trend analysis."""
    # In production, query from PostgreSQL timeseries
    history = []
    base_score = 82 if system_id != "credit-v3" else 74
    for i in range(days):
        date = datetime.utcnow() - timedelta(days=days - i)
        score = base_score + random.randint(-3, 3)
        history.append({"date": date.isoformat(), "score": max(0, min(100, score))})
    return history

# ── ROUTES: BIAS AUDITS ──────────────────────────────────────────────────────
@app.get("/api/v1/bias-audits/{system_id}", tags=["Bias Audits"])
async def get_bias_audit(system_id: str):
    """Get the latest bias audit results for an AI system."""
    if system_id not in db["systems"]:
        raise HTTPException(status_code=404, detail="System not found")

    # Simulate bias audit results
    results = []
    attributes = [
        ("Gender", "Male", 0.72), ("Gender", "Female", 0.61),
        ("Race", "White", 0.70), ("Race", "Black", 0.54), ("Race", "Hispanic", 0.63),
        ("Age", "18-30", 0.59), ("Age", "31-50", 0.74), ("Age", "51+", 0.68),
    ]
    for attr, group, rate in attributes:
        baseline = 0.72 if attr == "Gender" else 0.70 if attr == "Race" else 0.72
        disparity = rate - baseline
        severity = "critical" if abs(disparity) > 0.12 else "high" if abs(disparity) > 0.07 else "medium" if abs(disparity) > 0.03 else "low"
        results.append({
            "system_id": system_id,
            "attribute": attr,
            "group": group,
            "approval_rate": rate,
            "baseline_rate": baseline,
            "disparity": round(disparity, 3),
            "severity": severity,
        })
    return {"system_id": system_id, "results": results, "audit_date": datetime.utcnow().isoformat(), "overall_status": "fail"}

@app.post("/api/v1/bias-audits/{system_id}/run", tags=["Bias Audits"])
async def run_bias_audit(system_id: str, background_tasks: BackgroundTasks):
    """Trigger an on-demand bias audit for an AI system."""
    if system_id not in db["systems"]:
        raise HTTPException(status_code=404, detail="System not found")
    # In production, this enqueues a Celery task
    return {"status": "audit_queued", "estimated_completion": "2-5 minutes", "system_id": system_id}

# ── ROUTES: POLICY ENGINE ────────────────────────────────────────────────────
@app.get("/api/v1/policies", tags=["Policy Engine"])
async def list_policies():
    """List all active governance policies."""
    return list(db["policies"].values())

@app.post("/api/v1/policies", status_code=201, tags=["Policy Engine"])
async def create_policy(policy: PolicyRule):
    """Deploy a new policy-as-code governance rule."""
    db["policies"][policy.id] = policy.model_dump()
    await manager.broadcast({"type": "policy_deployed", "policy_id": policy.id, "name": policy.name})
    return policy

@app.post("/api/v1/policies/validate", tags=["Policy Engine"])
async def validate_policy(yaml_content: str):
    """Validate a policy YAML before deployment."""
    # In production, parse and validate the YAML
    errors = []
    warnings = []
    if "circuit_breakers" not in yaml_content:
        warnings.append("No circuit breakers defined — consider adding automated enforcement")
    if "frameworks" not in yaml_content:
        errors.append("Missing 'frameworks' field — required for compliance mapping")
    return {"valid": len(errors) == 0, "errors": errors, "warnings": warnings, "framework_coverage": ["eu-ai-act", "nist-rmf"] if len(errors) == 0 else []}

# ── ROUTES: INCIDENTS ────────────────────────────────────────────────────────
@app.get("/api/v1/incidents", tags=["Incidents"])
async def list_incidents(status: Optional[str] = None):
    """List all incidents, optionally filtered by status."""
    incidents = list(db["incidents"].values())
    if status:
        incidents = [i for i in incidents if i["status"] == status]
    return incidents

@app.post("/api/v1/incidents", status_code=201, tags=["Incidents"])
async def create_incident(incident: IncidentReport):
    """Log a new governance incident."""
    db["incidents"][incident.id] = incident.model_dump()
    await manager.broadcast({"type": "incident_created", "incident": incident.model_dump(mode="json")})
    return incident

@app.patch("/api/v1/incidents/{incident_id}/resolve", tags=["Incidents"])
async def resolve_incident(incident_id: str):
    """Mark an incident as resolved."""
    if incident_id not in db["incidents"]:
        raise HTTPException(status_code=404, detail="Incident not found")
    db["incidents"][incident_id]["status"] = "resolved"
    db["incidents"][incident_id]["resolved_at"] = datetime.utcnow().isoformat()
    return db["incidents"][incident_id]

# ── ROUTES: GOVERNANCE ADVISOR (AI-POWERED) ──────────────────────────────────
@app.post("/api/v1/advisor/chat", tags=["AI Advisor"])
async def governance_advisor_chat(msg: GovernanceAdvisorMessage):
    """
    AI-powered governance advisor powered by Anthropic Claude.
    Provides contextual advice on risk, compliance, and remediation.
    """
    response = await get_governance_advice(msg.message, msg.system_context)
    return {
        "response": response,
        "sources": ["EU AI Act Art. 9", "NIST AI RMF MANAGE 2.2", "Meridian Risk Library"],
        "timestamp": datetime.utcnow().isoformat(),
        "model": "claude-opus-4-6",
    }

# ── ROUTES: GOVERNANCE GRAPH ─────────────────────────────────────────────────
@app.get("/api/v1/governance-graph", tags=["Governance Graph"])
async def get_governance_graph():
    """
    Return the full governance knowledge graph.
    Nodes: AI systems, risks, controls, evidence, requirements, frameworks.
    Edges: relationships between all governance entities.
    """
    nodes = []
    edges = []

    for sys_id, sys in db["systems"].items():
        nodes.append({"id": sys_id, "type": "ai_system", "label": sys["name"], "risk": sys["risk_level"]})
        for fw in sys.get("frameworks", []):
            framework_node_id = f"fw-{fw}"
            if not any(n["id"] == framework_node_id for n in nodes):
                nodes.append({"id": framework_node_id, "type": "framework", "label": fw.upper()})
            edges.append({"source": sys_id, "target": framework_node_id, "type": "governed_by"})

    # Add risk nodes
    risk_types = ["bias-risk", "privacy-risk", "drift-risk", "security-risk"]
    for rt in risk_types:
        nodes.append({"id": rt, "type": "risk", "label": rt.replace("-", " ").title()})

    edges.append({"source": "credit-v3", "target": "bias-risk", "type": "has_risk", "severity": "critical"})
    edges.append({"source": "hr-screener", "target": "bias-risk", "type": "has_risk", "severity": "high"})
    edges.append({"source": "doc-agent", "target": "privacy-risk", "type": "has_risk", "severity": "medium"})

    return {"nodes": nodes, "edges": edges, "stats": {"total_nodes": len(nodes), "total_edges": len(edges)}}

# ── ROUTES: ANALYTICS / ROI ──────────────────────────────────────────────────
@app.get("/api/v1/analytics/roi", tags=["Analytics"])
async def calculate_roi(
    ai_budget_millions: float = 25.0,
    num_systems: int = 120,
    manual_hours_per_week: float = 15.0,
    engineer_salary_k: float = 145.0,
    incidents_per_year: int = 4,
    incident_cost_k: float = 850.0,
):
    """Calculate 3-year ROI from AI governance investment."""
    hourly_rate = (engineer_salary_k * 1000) / 2080
    labor_saving_3yr = manual_hours_per_week * 52 * hourly_rate * 0.72 * 3
    incident_saving_3yr = incidents_per_year * incident_cost_k * 1000 * 0.65 * 3
    velocity_value_3yr = num_systems * 8000 * 0.15 * 3
    platform_cost_3yr = max(180000, (num_systems * 1400 + 90000)) * 3
    net_value = labor_saving_3yr + incident_saving_3yr + velocity_value_3yr - platform_cost_3yr
    roi_pct = (net_value / platform_cost_3yr) * 100
    payback_months = max(4, int(36 / (roi_pct / 100 + 1)))

    return {
        "roi_percentage": round(roi_pct),
        "net_value_usd": round(net_value),
        "payback_months": payback_months,
        "breakdown": {
            "labor_savings_3yr": round(labor_saving_3yr),
            "incident_avoidance_3yr": round(incident_saving_3yr),
            "velocity_value_3yr": round(velocity_value_3yr),
            "platform_cost_3yr": round(platform_cost_3yr),
        },
        "methodology": "Credo AI 2026 ROI Playbook + Internal benchmarks",
    }

@app.get("/api/v1/analytics/dashboard", tags=["Analytics"])
async def get_dashboard_metrics():
    """Get overview dashboard metrics."""
    return {
        "total_systems": len(db["systems"]),
        "open_incidents": len([i for i in db["incidents"].values() if i["status"] == "open"]),
        "tripped_circuit_breakers": len([cb for cb in db["circuit_breakers"].values() if cb["state"] == "tripped"]),
        "governance_score": 82,
        "monetary_exposure_usd": sum(s.get("monetary_exposure", 0) for s in db["systems"].values()),
        "compliance_coverage": {"eu_ai_act": 88, "nist_rmf": 94, "iso_42001": 79, "soc2": 97, "gdpr": 85},
        "shadow_ai_count": 31,
        "total_agents": 38,
        "timestamp": datetime.utcnow().isoformat(),
    }

# ── WEBSOCKET: REAL-TIME AGENT STREAM ────────────────────────────────────────
@app.websocket("/ws/agents")
async def agent_stream(ws: WebSocket):
    """
    WebSocket endpoint for real-time agent monitoring.
    Streams: heartbeats, circuit breaker events, anomaly alerts.

    Client usage:
        const ws = new WebSocket('ws://localhost:8000/ws/agents');
        ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            // data.type: 'heartbeat' | 'circuit_breaker_tripped' | 'incident_created' | 'system_registered'
        };
    """
    await manager.connect(ws)
    try:
        while True:
            # Keep connection alive, wait for client pings
            data = await ws.receive_text()
            if data == "ping":
                await ws.send_text("pong")
    except WebSocketDisconnect:
        manager.disconnect(ws)

# ── HEALTH CHECK ─────────────────────────────────────────────────────────────
@app.get("/health")
async def health():
    return {"status": "ok", "version": "2.0.0", "timestamp": datetime.utcnow().isoformat()}

# ── RUN ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
