import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { createServer } from 'http';
import { WebSocketServer } from 'ws';
import { rateLimit } from 'express-rate-limit';
import { agentRoutes } from './routes/agents';
import { riskRoutes } from './routes/risk';
import { registryRoutes } from './routes/registry';
import { policyRoutes } from './routes/policy';
import { incidentRoutes } from './routes/incidents';
import { evidenceRoutes } from './routes/evidence';
import { vendorRoutes } from './routes/vendors';
import { analyticsRoutes } from './routes/analytics';
import { authMiddleware } from './middleware/auth';
import { auditLogger } from './middleware/audit';
import { AgentMonitorService } from './services/AgentMonitorService';
import { RiskEngineService } from './services/RiskEngineService';
import { PolicyEnforcerService } from './services/PolicyEnforcerService';
import { db } from './lib/database';
import { logger } from './lib/logger';

const app = express();
const server = createServer(app);

// ── WebSocket for real-time agent monitoring ──
const wss = new WebSocketServer({ server, path: '/ws' });
const agentMonitor = new AgentMonitorService(wss);

// ── Services ──
const riskEngine = new RiskEngineService();
const policyEnforcer = new PolicyEnforcerService(agentMonitor);

// ── Middleware ──
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.ALLOWED_ORIGINS?.split(',') || '*' }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 500 });
app.use(limiter);

app.use(auditLogger);

// ── Health ──
app.get('/health', (_, res) => res.json({
  status: 'operational',
  version: process.env.npm_package_version,
  timestamp: new Date().toISOString(),
  services: {
    database: db.isConnected() ? 'up' : 'down',
    agentMonitor: agentMonitor.isRunning() ? 'up' : 'down',
    riskEngine: riskEngine.isReady() ? 'up' : 'down',
  }
}));

// ── Protected routes ──
app.use('/api/v1', authMiddleware);
app.use('/api/v1/agents', agentRoutes(agentMonitor, policyEnforcer));
app.use('/api/v1/risk', riskRoutes(riskEngine));
app.use('/api/v1/registry', registryRoutes);
app.use('/api/v1/policy', policyRoutes(policyEnforcer));
app.use('/api/v1/incidents', incidentRoutes);
app.use('/api/v1/evidence', evidenceRoutes);
app.use('/api/v1/vendors', vendorRoutes);
app.use('/api/v1/analytics', analyticsRoutes);

// ── Webhook endpoint (public, separately auth'd) ──
app.post('/webhooks/:provider', async (req, res) => {
  const { provider } = req.params;
  try {
    await handleWebhook(provider, req.body, req.headers);
    res.json({ received: true });
  } catch (err) {
    logger.error('Webhook error', { provider, err });
    res.status(400).json({ error: 'Webhook processing failed' });
  }
});

async function handleWebhook(provider: string, body: unknown, headers: Record<string, string | string[] | undefined>) {
  const { default: handler } = await import(`../../integrations/${provider}/webhook`);
  return handler(body, headers);
}

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  logger.info(`Meridian API running on port ${PORT}`);
  agentMonitor.startHeartbeat();
  riskEngine.startContinuousAssessment();
});

export { app, wss };
