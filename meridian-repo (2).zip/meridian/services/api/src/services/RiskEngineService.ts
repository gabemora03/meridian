import Anthropic from '@anthropic-ai/sdk';
import { db } from '../lib/database';
import { logger } from '../lib/logger';
import type { AgentState, AgentAction } from './AgentMonitorService';

/**
 * AgentDNA™ — Meridian's proprietary behavioral fingerprinting
 * This is the core moat: we build a behavioral model per agent
 * and detect anomalies using exponential moving averages + LLM reasoning
 */
interface AgentDNA {
  agentId: string;
  // Behavioral signatures
  avgActionsPerHour: number;
  resourcePatterns: Record<string, number>; // resource -> frequency
  actionTypeDistribution: Record<string, number>;
  temporalPattern: number[]; // 24-hour activity heatmap
  avgRiskScore: number;
  anomalyScore: number; // How much current behavior deviates from baseline
  lastUpdated: Date;
}

interface MonetaryRiskEstimate {
  expectedLoss: number; // $ expected annual loss
  worstCase: number;
  probability: number;
  confidenceInterval: [number, number];
  factors: {
    name: string;
    contribution: number;
    mitigatable: boolean;
  }[];
}

interface RiskAssessment {
  systemId: string;
  overallScore: number; // 0-100
  monetaryExposure: MonetaryRiskEstimate;
  categories: {
    bias: number;
    privacy: number;
    security: number;
    explainability: number;
    drift: number;
    compliance: number;
  };
  agentDNA?: AgentDNA;
  llmReasoning?: string;
  recommendations: string[];
  nextAssessmentAt: Date;
}

export class RiskEngineService {
  private anthropic: Anthropic;
  private dnaCache = new Map<string, AgentDNA>();
  private assessmentInterval: NodeJS.Timeout | null = null;
  private ready = false;

  constructor() {
    this.anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
    this.ready = true;
  }

  /**
   * Score an individual agent action in real-time (<10ms target)
   */
  async scoreAction(
    agent: AgentState,
    action: Omit<AgentAction, 'riskScore' | 'policyViolations' | 'traceId'>,
    violations: string[]
  ): Promise<number> {
    let score = 0;

    // Base risk from action type
    const actionWeights: Record<string, number> = {
      read: 5, write: 20, execute: 35, commit: 45, send: 40, delete: 60
    };
    score += actionWeights[action.actionType] || 10;

    // Amplify by agent risk history
    const dna = this.dnaCache.get(agent.id);
    if (dna && dna.anomalyScore > 0.5) score *= (1 + dna.anomalyScore);

    // Shadow agents get max score
    if (agent.type === 'shadow') score = 100;

    // Violations add to score
    score += violations.length * 15;

    // Normalize to 0-100
    return Math.min(100, Math.round(score));
  }

  /**
   * Full risk assessment for an AI system
   * Uses Claude for qualitative reasoning on top of quantitative scores
   */
  async assessSystem(systemId: string): Promise<RiskAssessment> {
    const system = await db.aiSystems.findUnique({ where: { id: systemId }, include: { actions: { take: 1000 }, incidents: true } });
    if (!system) throw new Error(`System ${systemId} not found`);

    // Quantitative scores
    const categories = await this.calculateCategoryScores(system);
    const overallScore = this.weightedAverage(categories);
    const monetary = await this.estimateMonetaryRisk(system, overallScore);

    // Update/compute AgentDNA if this is an agent
    let agentDNA: AgentDNA | undefined;
    if (system.type === 'agent') {
      agentDNA = await this.computeAgentDNA(systemId, system.actions);
      this.dnaCache.set(systemId, agentDNA);
    }

    // LLM reasoning for high-risk systems
    let llmReasoning: string | undefined;
    let recommendations: string[] = [];

    if (overallScore > 50) {
      const result = await this.getLLMRiskReasoning(system, categories, monetary);
      llmReasoning = result.reasoning;
      recommendations = result.recommendations;
    }

    const assessment: RiskAssessment = {
      systemId,
      overallScore,
      monetaryExposure: monetary,
      categories,
      agentDNA,
      llmReasoning,
      recommendations,
      nextAssessmentAt: new Date(Date.now() + (overallScore > 70 ? 3600000 : 86400000)), // 1h for high risk, 24h otherwise
    };

    await db.riskAssessments.create({ data: { systemId, ...assessment, categories: JSON.stringify(categories) } });
    return assessment;
  }

  /**
   * Compute AgentDNA — the behavioral fingerprint
   * This is what makes Meridian's agent governance unique
   */
  private async computeAgentDNA(agentId: string, actions: AgentAction[]): Promise<AgentDNA> {
    const existing = this.dnaCache.get(agentId);

    const resourcePatterns: Record<string, number> = {};
    const actionTypeDistribution: Record<string, number> = {};
    const temporalPattern = new Array(24).fill(0);

    for (const action of actions) {
      resourcePatterns[action.resource] = (resourcePatterns[action.resource] || 0) + 1;
      actionTypeDistribution[action.actionType] = (actionTypeDistribution[action.actionType] || 0) + 1;
      const hour = new Date(action.timestamp).getHours();
      temporalPattern[hour]++;
    }

    // Normalize distributions
    const total = actions.length || 1;
    Object.keys(actionTypeDistribution).forEach(k => actionTypeDistribution[k] /= total);
    const maxTemporal = Math.max(...temporalPattern, 1);
    temporalPattern.forEach((_, i) => temporalPattern[i] /= maxTemporal);

    // Compute anomaly score vs existing baseline
    let anomalyScore = 0;
    if (existing) {
      // KL divergence approximation between current and baseline distributions
      anomalyScore = this.computeDistributionDivergence(
        actionTypeDistribution,
        existing.actionTypeDistribution
      );
    }

    const avgActionsPerHour = actions.filter(a =>
      Date.now() - new Date(a.timestamp).getTime() < 3600000
    ).length;

    const avgRiskScore = actions.reduce((sum, a) => sum + a.riskScore, 0) / total;

    return {
      agentId,
      avgActionsPerHour,
      resourcePatterns,
      actionTypeDistribution,
      temporalPattern,
      avgRiskScore,
      anomalyScore,
      lastUpdated: new Date(),
    };
  }

  private computeDistributionDivergence(p: Record<string, number>, q: Record<string, number>): number {
    // Symmetric KL divergence (Jensen-Shannon)
    const keys = new Set([...Object.keys(p), ...Object.keys(q)]);
    let divergence = 0;
    const eps = 1e-10;
    keys.forEach(k => {
      const pi = (p[k] || eps);
      const qi = (q[k] || eps);
      const m = (pi + qi) / 2;
      divergence += pi * Math.log(pi / m) / 2 + qi * Math.log(qi / m) / 2;
    });
    return Math.min(1, divergence); // Normalize to [0,1]
  }

  private async calculateCategoryScores(system: { type: string; riskLevel: string; incidents: { category: string }[]; actions: AgentAction[] }): Promise<RiskAssessment['categories']> {
    const incidentWeight = Math.min(system.incidents.length * 8, 40);
    const baseRisk = { low: 10, medium: 35, high: 65, critical: 85 }[system.riskLevel] || 35;

    return {
      bias: baseRisk + (system.incidents.filter(i => i.category === 'bias').length * 10),
      privacy: baseRisk * 0.8 + (system.type === 'agent' ? 15 : 5),
      security: baseRisk * 0.7 + incidentWeight * 0.3,
      explainability: system.type === 'agent' ? baseRisk + 20 : baseRisk,
      drift: Math.max(10, baseRisk - 15 + (system.actions.length > 500 ? 10 : 0)),
      compliance: Math.max(5, baseRisk - 10),
    };
  }

  private weightedAverage(scores: RiskAssessment['categories']): number {
    const weights = { bias: 0.25, privacy: 0.20, security: 0.20, explainability: 0.15, drift: 0.10, compliance: 0.10 };
    return Math.round(Object.entries(scores).reduce((sum, [k, v]) => sum + v * weights[k as keyof typeof weights], 0));
  }

  private async estimateMonetaryRisk(system: { riskLevel: string; revenue?: number }, score: number): Promise<MonetaryRiskEstimate> {
    // Based on Credo AI 2026 ROI Playbook risk quantification methodology
    const globalRevenue = system.revenue || 50_000_000;
    const euAIActMaxFine = globalRevenue * 0.06;
    const probability = score / 200; // Convert score to probability (max 50% at score 100)

    const base = euAIActMaxFine * probability;
    const litigationMultiplier = score > 70 ? 1.8 : 1.2;

    return {
      expectedLoss: Math.round(base * litigationMultiplier),
      worstCase: Math.round(euAIActMaxFine * litigationMultiplier),
      probability: Math.round(probability * 100) / 100,
      confidenceInterval: [Math.round(base * 0.6), Math.round(base * litigationMultiplier * 1.5)],
      factors: [
        { name: 'EU AI Act non-compliance fine', contribution: 0.45, mitigatable: true },
        { name: 'Customer churn from AI failure', contribution: 0.20, mitigatable: true },
        { name: 'Litigation exposure', contribution: 0.20, mitigatable: false },
        { name: 'Operational rework cost', contribution: 0.10, mitigatable: true },
        { name: 'Capital cost increase', contribution: 0.05, mitigatable: false },
      ],
    };
  }

  private async getLLMRiskReasoning(
    system: unknown,
    categories: RiskAssessment['categories'],
    monetary: MonetaryRiskEstimate
  ): Promise<{ reasoning: string; recommendations: string[] }> {
    try {
      const response = await this.anthropic.messages.create({
        model: 'claude-opus-4-6',
        max_tokens: 600,
        system: `You are Meridian's AI Risk Analyst. You reason about AI governance risks concisely and precisely. Always quantify monetary impact where possible. Be direct, not hedging.`,
        messages: [{
          role: 'user',
          content: `Analyze this AI system risk profile and provide exactly 3 actionable recommendations:

System: ${JSON.stringify(system, null, 2)}
Risk Scores: ${JSON.stringify(categories)}
Monetary Exposure: $${monetary.expectedLoss.toLocaleString()} expected, $${monetary.worstCase.toLocaleString()} worst case

Respond in JSON: { "reasoning": "2-3 sentence analysis", "recommendations": ["rec1", "rec2", "rec3"] }`
        }]
      });

      const content = response.content[0];
      if (content.type !== 'text') throw new Error('Unexpected response type');
      const parsed = JSON.parse(content.text);
      return { reasoning: parsed.reasoning, recommendations: parsed.recommendations };
    } catch (err) {
      logger.error('LLM risk reasoning failed', { err });
      return {
        reasoning: 'Automated risk analysis unavailable. Manual review recommended.',
        recommendations: ['Review bias testing coverage', 'Update compliance documentation', 'Schedule penetration test']
      };
    }
  }

  startContinuousAssessment(): void {
    // Re-assess high-risk systems every hour, others daily
    this.assessmentInterval = setInterval(async () => {
      const systems = await db.aiSystems.findMany({ where: { status: { not: 'retired' } } });
      for (const system of systems) {
        if (system.riskLevel === 'critical' || system.riskLevel === 'high') {
          await this.assessSystem(system.id).catch(err =>
            logger.error('Continuous assessment failed', { systemId: system.id, err })
          );
        }
      }
    }, 3600000); // Every hour
  }

  isReady(): boolean { return this.ready; }
}
