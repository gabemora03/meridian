import { WebSocketServer, WebSocket } from 'ws';
import { EventEmitter } from 'events';
import { db } from '../lib/database';
import { logger } from '../lib/logger';
import { RiskEngineService } from './RiskEngineService';

export interface AgentAction {
  agentId: string;
  agentName: string;
  actionType: 'read' | 'write' | 'execute' | 'commit' | 'send' | 'delete';
  resource: string;
  payload?: unknown;
  timestamp: Date;
  autonomyLevel: 'observe' | 'recommend' | 'propose' | 'execute-limited' | 'unauthorized';
  riskScore: number;
  policyViolations: string[];
  traceId: string;
}

export interface AgentState {
  id: string;
  name: string;
  type: 'internal' | 'vendor' | 'shadow';
  autonomyLevel: string;
  permissions: string[];
  actionsToday: number;
  riskScore: number;
  status: 'active' | 'monitoring' | 'suspended' | 'killed';
  lastSeen: Date;
  killSwitchArmed: boolean;
  parentAgentId?: string;
  childAgentIds: string[];
}

export class AgentMonitorService extends EventEmitter {
  private wss: WebSocketServer;
  private clients = new Set<WebSocket>();
  private agents = new Map<string, AgentState>();
  private actionBuffer: AgentAction[] = [];
  private heartbeatInterval: NodeJS.Timeout | null = null;
  private running = false;
  private riskEngine = new RiskEngineService();

  constructor(wss: WebSocketServer) {
    super();
    this.wss = wss;
    this.setupWebSocket();
    this.seedAgents();
  }

  private setupWebSocket() {
    this.wss.on('connection', (ws, req) => {
      const clientId = req.headers['x-client-id'] || 'anon';
      logger.info('Agent monitor client connected', { clientId });
      this.clients.add(ws);

      // Send current state immediately
      ws.send(JSON.stringify({
        type: 'INITIAL_STATE',
        agents: Array.from(this.agents.values()),
        recentActions: this.actionBuffer.slice(-50),
      }));

      ws.on('message', (data) => {
        try {
          const msg = JSON.parse(data.toString());
          this.handleClientMessage(ws, msg);
        } catch { /* ignore malformed */ }
      });

      ws.on('close', () => {
        this.clients.delete(ws);
        logger.info('Agent monitor client disconnected', { clientId });
      });
    });
  }

  private handleClientMessage(ws: WebSocket, msg: { type: string; agentId?: string; level?: string }) {
    switch (msg.type) {
      case 'KILL_AGENT':
        if (msg.agentId) this.killAgent(msg.agentId, 'operator-initiated');
        break;
      case 'SUSPEND_AGENT':
        if (msg.agentId) this.suspendAgent(msg.agentId);
        break;
      case 'SET_AUTONOMY_LEVEL':
        if (msg.agentId && msg.level) this.setAutonomyLevel(msg.agentId, msg.level);
        break;
      case 'SUBSCRIBE_AGENT':
        // Client wants action stream for a specific agent
        ws.send(JSON.stringify({ type: 'SUBSCRIBED', agentId: msg.agentId }));
        break;
    }
  }

  /**
   * Core method: ingest an action from an agent and evaluate it
   * This is the enforcement point — policies are checked HERE
   */
  async ingestAction(action: Omit<AgentAction, 'riskScore' | 'policyViolations' | 'traceId'>): Promise<{
    allowed: boolean;
    violations: string[];
    riskScore: number;
    recommendation?: string;
  }> {
    const traceId = crypto.randomUUID();
    const agent = this.agents.get(action.agentId);

    if (!agent) {
      logger.warn('Unknown agent attempted action', { agentId: action.agentId });
      return { allowed: false, violations: ['AGENT_NOT_REGISTERED'], riskScore: 100 };
    }

    // Evaluate against policies
    const violations = await this.checkPolicyViolations(agent, action);
    const riskScore = await this.riskEngine.scoreAction(agent, action, violations);

    const fullAction: AgentAction = {
      ...action,
      riskScore,
      policyViolations: violations,
      traceId,
      timestamp: new Date(),
    };

    // Auto-kill if critical violations
    if (violations.includes('UNAUTHORIZED_PERMISSION') || riskScore > 90) {
      await this.killAgent(action.agentId, `auto-kill: violation=${violations[0]}`);
      this.broadcast({ type: 'ACTION_BLOCKED', action: fullAction, reason: violations[0] });
      return { allowed: false, violations, riskScore, recommendation: 'Agent suspended. Review required.' };
    }

    // Log action to DB
    await db.agentActions.create({ data: fullAction });

    // Update agent state
    agent.actionsToday++;
    agent.lastSeen = new Date();
    agent.riskScore = Math.max(agent.riskScore, riskScore * 0.1 + agent.riskScore * 0.9); // EWMA

    // Add to buffer and broadcast
    this.actionBuffer.push(fullAction);
    if (this.actionBuffer.length > 1000) this.actionBuffer.shift();
    this.broadcast({ type: 'AGENT_ACTION', action: fullAction });

    return { allowed: violations.length === 0, violations, riskScore };
  }

  private async checkPolicyViolations(agent: AgentState, action: Omit<AgentAction, 'riskScore' | 'policyViolations' | 'traceId'>): Promise<string[]> {
    const violations: string[] = [];

    // Check if agent is trying to do something beyond its permissions
    if (!agent.permissions.includes(action.actionType)) {
      violations.push('UNAUTHORIZED_PERMISSION');
    }

    // Autonomy level checks
    if (agent.autonomyLevel === 'observe' && ['write', 'execute', 'commit', 'send'].includes(action.actionType)) {
      violations.push('EXCEEDS_AUTONOMY_LEVEL');
    }

    // Shadow agents are always violations
    if (agent.type === 'shadow') {
      violations.push('SHADOW_AGENT_ACTION');
    }

    // Check against active policies in DB
    const activePolicies = await db.policies.findMany({ where: { active: true } });
    for (const policy of activePolicies) {
      if (await this.violatesPolicy(policy, agent, action)) {
        violations.push(`POLICY_VIOLATION:${policy.id}`);
      }
    }

    return violations;
  }

  private async violatesPolicy(policy: { rules: string }, agent: AgentState, action: unknown): Promise<boolean> {
    // Policy-as-code: evaluate JSON rules
    try {
      const rules = JSON.parse(policy.rules);
      return this.evaluateRules(rules, { agent, action });
    } catch {
      return false;
    }
  }

  private evaluateRules(rules: { type: string; field: string; operator: string; value: unknown; rules?: unknown[] }, ctx: unknown): boolean {
    // Simple rule engine — extend with full expression language
    if (rules.type === 'AND') return (rules.rules || []).every((r: unknown) => this.evaluateRules(r as { type: string; field: string; operator: string; value: unknown; rules?: unknown[] }, ctx));
    if (rules.type === 'OR') return (rules.rules || []).some((r: unknown) => this.evaluateRules(r as { type: string; field: string; operator: string; value: unknown; rules?: unknown[] }, ctx));
    if (rules.type === 'CONDITION') {
      const val = this.getField(ctx as Record<string, unknown>, rules.field);
      switch (rules.operator) {
        case 'eq': return val === rules.value;
        case 'gt': return Number(val) > Number(rules.value);
        case 'in': return Array.isArray(rules.value) && rules.value.includes(val);
        default: return false;
      }
    }
    return false;
  }

  private getField(obj: Record<string, unknown>, path: string): unknown {
    return path.split('.').reduce((o: unknown, k) => (o as Record<string, unknown>)?.[k], obj);
  }

  async killAgent(agentId: string, reason: string): Promise<void> {
    const agent = this.agents.get(agentId);
    if (!agent) return;
    agent.status = 'killed';
    await db.agents.update({ where: { id: agentId }, data: { status: 'killed', killedAt: new Date(), killReason: reason } });
    this.broadcast({ type: 'AGENT_KILLED', agentId, reason, timestamp: new Date() });
    this.emit('agent:killed', { agentId, reason });
    logger.warn('Agent killed', { agentId, reason });
  }

  async suspendAgent(agentId: string): Promise<void> {
    const agent = this.agents.get(agentId);
    if (!agent) return;
    agent.status = 'suspended';
    await db.agents.update({ where: { id: agentId }, data: { status: 'suspended' } });
    this.broadcast({ type: 'AGENT_SUSPENDED', agentId, timestamp: new Date() });
  }

  setAutonomyLevel(agentId: string, level: string): void {
    const agent = this.agents.get(agentId);
    if (!agent) return;
    agent.autonomyLevel = level;
    this.broadcast({ type: 'AUTONOMY_CHANGED', agentId, level });
  }

  private broadcast(msg: unknown): void {
    const payload = JSON.stringify(msg);
    this.clients.forEach(ws => {
      if (ws.readyState === WebSocket.OPEN) ws.send(payload);
    });
  }

  startHeartbeat(): void {
    this.running = true;
    this.heartbeatInterval = setInterval(() => {
      // Simulate realistic agent activity
      this.simulateAgentActivity();
      // Broadcast heartbeat with live stats
      this.broadcast({
        type: 'HEARTBEAT',
        timestamp: new Date(),
        stats: {
          activeAgents: Array.from(this.agents.values()).filter(a => a.status === 'active').length,
          actionsLastMinute: this.actionBuffer.filter(a => Date.now() - a.timestamp.getTime() < 60000).length,
          criticalAlerts: this.actionBuffer.filter(a => a.riskScore > 80 && Date.now() - a.timestamp.getTime() < 300000).length,
        }
      });
    }, 3000);
  }

  private simulateAgentActivity(): void {
    // In production, this receives real agent telemetry via gRPC/NATS
    // For dev, simulate realistic action patterns
    const agents = Array.from(this.agents.values()).filter(a => a.status === 'active');
    if (!agents.length) return;
    const agent = agents[Math.floor(Math.random() * agents.length)];
    const actionTypes = agent.permissions as AgentAction['actionType'][];
    const action: Omit<AgentAction, 'riskScore' | 'policyViolations' | 'traceId'> = {
      agentId: agent.id,
      agentName: agent.name,
      actionType: actionTypes[Math.floor(Math.random() * actionTypes.length)],
      resource: ['customer-db', 'email-api', 'payment-service', 'crm-api'][Math.floor(Math.random() * 4)],
      timestamp: new Date(),
      autonomyLevel: agent.autonomyLevel as AgentAction['autonomyLevel'],
    };
    this.ingestAction(action).catch(console.error);
  }

  private seedAgents(): void {
    const seed: AgentState[] = [
      { id: 'agent-001', name: 'Document Processor', type: 'internal', autonomyLevel: 'observe', permissions: ['read', 'write'], actionsToday: 4201, riskScore: 12, status: 'active', lastSeen: new Date(), killSwitchArmed: true, childAgentIds: [] },
      { id: 'agent-002', name: 'Procurement Autopilot', type: 'internal', autonomyLevel: 'execute-limited', permissions: ['read', 'write', 'commit'], actionsToday: 892, riskScore: 44, status: 'monitoring', lastSeen: new Date(), killSwitchArmed: true, childAgentIds: ['agent-005'] },
      { id: 'agent-003', name: 'Customer Outreach Bot', type: 'internal', autonomyLevel: 'recommend', permissions: ['read'], actionsToday: 6041, riskScore: 8, status: 'active', lastSeen: new Date(), killSwitchArmed: true, childAgentIds: [] },
      { id: 'agent-004', name: 'Rogue Sales Agent', type: 'shadow', autonomyLevel: 'unauthorized', permissions: ['read', 'write', 'send', 'commit'], actionsToday: 1713, riskScore: 97, status: 'killed', lastSeen: new Date(), killSwitchArmed: false, childAgentIds: [] },
      { id: 'agent-005', name: 'Invoice Sub-Agent', type: 'internal', autonomyLevel: 'recommend', permissions: ['read', 'write'], actionsToday: 201, riskScore: 21, status: 'active', lastSeen: new Date(), killSwitchArmed: true, parentAgentId: 'agent-002', childAgentIds: [] },
    ];
    seed.forEach(a => this.agents.set(a.id, a));
  }

  isRunning(): boolean { return this.running; }

  getAgents(): AgentState[] { return Array.from(this.agents.values()); }
}
