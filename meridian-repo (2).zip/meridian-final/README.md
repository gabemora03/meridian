# Meridian — AI Governance Platform

**The only platform with AgentDNA™ behavioral fingerprinting, monetary risk quantification, visual Agent Builder, and sub-10ms policy enforcement.**

![Version](https://img.shields.io/badge/version-0.9.0--beta-lime?style=flat-square)
![License](https://img.shields.io/badge/license-Proprietary-red?style=flat-square)
![TypeScript](https://img.shields.io/badge/TypeScript-5.x-blue?style=flat-square)

---

## What makes Meridian different

| Capability | Credo AI | Diligent | MetricStream | Reco.ai | **Meridian** |
|---|---|---|---|---|---|
| Visual Agent Builder | ✗ | ✗ | ✗ | ✗ | **✓** |
| AgentDNA™ fingerprinting | ✗ | ✗ | ✗ | ✗ | **✓** |
| Monetary risk in $ | ✗ | ✗ | ✗ | ✗ | **✓** |
| Real-time enforcement (<10ms) | ✗ | ✗ | ✗ | Partial | **✓** |
| NL → Policy-as-code via Claude | ✗ | ✗ | ✗ | ✗ | **✓** |
| Conversational governance UI | ✗ | ✗ | ✗ | ✗ | **✓** |
| Predictive risk forecasting | Partial | ✗ | ✗ | ✗ | **✓** |

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         Meridian Platform                        │
│                                                                   │
│  ┌──────────────────┐  ┌──────────────────┐  ┌───────────────┐  │
│  │   Dashboard App  │  │  Marketing Site  │  │    SDK (npm)  │  │
│  │  apps/app/       │  │  apps/web/       │  │  packages/sdk │  │
│  └────────┬─────────┘  └──────────────────┘  └───────┬───────┘  │
│           │                                           │          │
│           ▼                                           ▼          │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │                    API Server (:4000)                       │  │
│  │   services/api/src/index.ts                                │  │
│  │                                                            │  │
│  │  ┌─────────────────┐  ┌─────────────────┐                 │  │
│  │  │ AgentMonitor    │  │  RiskEngine     │                 │  │
│  │  │ • <10ms enforce │  │  • Monte Carlo  │                 │  │
│  │  │ • AgentDNA™ JSD │  │  • $ exposure   │                 │  │
│  │  │ • Kill switches │  │  • Claude AI    │                 │  │
│  │  └─────────────────┘  └─────────────────┘                 │  │
│  │  ┌─────────────────┐  ┌─────────────────┐                 │  │
│  │  │ PolicyEnforcer  │  │  GovernanceAdv. │                 │  │
│  │  │ • 50ns cache    │  │  • Claude stream│                 │  │
│  │  │ • Policy-as-code│  │  • NL → policy │                 │  │
│  │  └─────────────────┘  └─────────────────┘                 │  │
│  └────────────────────────────────────────────────────────────┘  │
│           │                         │                            │
│           ▼                         ▼                            │
│  ┌─────────────────┐     ┌────────────────────┐                 │
│  │   PostgreSQL 16  │     │    Redis 7          │                 │
│  │   (Prisma ORM)  │     │  • Policy cache     │                 │
│  │   • All data    │     │  • AgentDNA buffers │                 │
│  │   • Audit trail │     │  • Risk cache (1h) │                 │
│  └─────────────────┘     └────────────────────┘                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Quick start

### Prerequisites
- Node.js 20+
- Docker & Docker Compose
- Anthropic API key

### 1. Clone and configure

```bash
git clone https://github.com/your-org/meridian-ai
cd meridian-ai
cp .env.example .env
# Edit .env — add your ANTHROPIC_API_KEY
```

### 2. Start with Docker (recommended)

```bash
docker compose up -d
```

The platform will be available at:
- **Dashboard**: http://localhost:3000
- **Marketing site**: http://localhost:8080
- **API**: http://localhost:4000
- **Health check**: http://localhost:4000/health

### 3. Or run locally

```bash
# Install dependencies
npm install

# Start PostgreSQL + Redis
docker compose up postgres redis -d

# Run migrations
cd services/api && npx prisma migrate dev

# Start all services
npm run dev
```

---

## SDK usage

```bash
npm install @meridian/sdk
```

```typescript
import Meridian from '@meridian/sdk';

const meridian = new Meridian(process.env.MERIDIAN_API_KEY);

// Govern any agent action — enforces in <10ms
try {
  await meridian.agent('my-agent').govern({
    actionType: 'send_email',
    resource: 'external@customer.com',
    payload: { subject, body },
  });
  // Allowed — proceed
  await sendEmail(subject, body);
} catch (err) {
  if (err instanceof GovernanceBlockedError) {
    // Blocked by policy — audit trail created automatically
    console.log('Blocked:', err.decision.reason);
  }
}

// Get monetary risk assessment
const risk = await meridian.assessRisk('credit-model-v3');
console.log(`Expected annual loss: $${risk.monetary.expectedAnnualLoss.toLocaleString()}`);

// Generate policy from natural language
const policy = await meridian.generatePolicy(
  'Block any agent from sending more than 100 emails per hour'
);

// Subscribe to real-time governance events
meridian.subscribe(['action_blocked', 'drift_detected']);
meridian.on('drift_detected', ({ agentId, divergenceScore }) => {
  console.log(`AgentDNA™ drift: ${agentId} JSD=${divergenceScore}`);
});
```

---

## Repository structure

```
meridian-ai/
├── apps/
│   ├── app/                    # Main platform dashboard (HTML/JS)
│   └── web/                    # Marketing website (HTML/JS)
├── services/
│   └── api/
│       ├── src/
│       │   ├── index.ts                    # Express + WebSocket server
│       │   ├── services/
│       │   │   ├── AgentMonitorService.ts  # Real-time enforcement + AgentDNA™
│       │   │   ├── RiskEngineService.ts    # Monetary risk + Monte Carlo
│       │   │   ├── PolicyEnforcerService.ts
│       │   │   ├── EvidenceService.ts
│       │   │   └── GovernanceAdvisorService.ts
│       │   ├── routes/                     # Express route handlers
│       │   └── middleware/                 # Auth, audit logging
│       └── prisma/schema.prisma
├── packages/
│   └── sdk/src/index.ts        # @meridian/sdk TypeScript library
├── integrations/
│   ├── anthropic/              # Claude streaming integration
│   ├── langchain/              # LangChain middleware
│   └── webhooks/               # Jira, Slack, ServiceNow webhooks
├── infrastructure/
│   ├── docker/                 # Dockerfiles
│   ├── k8s/                    # Kubernetes manifests
│   └── nginx/                  # Nginx config
├── .github/workflows/ci.yml    # CI/CD pipeline
├── docker-compose.yml
├── vercel.json                 # One-click Vercel deploy
├── railway.json                # Railway deploy config
└── .env.example
```

---

## Key pages in the dashboard

| Page | Description |
|---|---|
| Dashboard | Predictive insight card, modular drag-and-drop widgets, live activity |
| AI Registry | 247 systems with model cards, shadow AI detection, monetary exposure |
| Agent Monitor | Live canvas network graph, kill switches, AgentDNA™ scores |
| Risk Intelligence | Compliance rings, monetary risk bar chart, risk heatmap |
| **Agent Builder** | 6-step wizard — template → goals → protocols → triggers → permissions → deploy |
| Agent Library | Deployed governance agents with run/kill controls |
| Policy Engine | Framework coverage radar, approval pipeline, policy packs |
| AI Advisor | Conversational UI powered by Claude with full governance context |
| Governance Graph | SVG knowledge graph — systems → risks → controls → evidence → frameworks |
| Bias Audits | Demographic parity bars, fairness radar, Bertrand-Mullainathan methodology |
| Data Lineage | Pipeline visualization with privacy flag detection |
| Incidents | SLA timers, AI-powered root cause analysis |
| Evidence Library | Reuse tracking across 40 frameworks |
| Regulatory Tracker | Live global regulation tracker |
| Integration Hub | 40+ integrations — identity, GRC, legal, incident, audit, data, AI usage, comms |
| Audit Trail | Every AI decision with WHY transparency panels |
| ROI Calculator | 6-slider Monte Carlo with live chart |
| Maturity Score | 6-level maturity with radar and gap analysis |

---

## Competitive moat

1. **AgentDNA™** — Jensen-Shannon divergence behavioral fingerprinting. No competitor has this.
2. **Monetary risk quantification** — Monte Carlo simulation with EU AI Act fine structure baked in. First platform to speak CFO language.
3. **Visual Agent Builder** — 6-step wizard to design governance agents from scratch, inspired by EquiAudit methodology. No competitor has UX for this.
4. **<10ms enforcement** — Redis-cached policy engine at the agent action layer. Not a weekly report — actual blocking.

---

## Environment variables

See `.env.example` for all required variables.

Critical:
- `ANTHROPIC_API_KEY` — Powers AI Advisor and policy generation
- `DATABASE_URL` — PostgreSQL connection string
- `REDIS_URL` — Redis connection string
- `JWT_SECRET` — API authentication

---

## License

Proprietary — Meridian AI Inc. © 2026. All rights reserved.

Contact: founders@meridian.ai
